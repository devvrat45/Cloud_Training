window._config = {
    cognito: {
        userPoolId: 'ap-south-1_7MfYPTNKe', // e.g. us-east-2_uXboG5pAb
        userPoolClientId: '7kr1ivvorqat7pqlt2kp93ll4r', // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
        region: 'ap-south-1' // e.g. us-east-2
    },
    api: {
        invokeUrl: 'https://msyvwv7mh8.execute-api.ap-south-1.amazonaws.com/default/bookManagement' // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod,
    }
};
